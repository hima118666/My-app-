# React Student Management System

## Files
- App.js
- App.css
- index.js

## Run
1. Create a React app:
   npx create-react-app student-management
2. Replace src/App.js with the provided App.js.
3. Replace src/App.css with the provided App.css.
4. Replace src/index.js with the provided index.js.
5. Run:
   npm start
