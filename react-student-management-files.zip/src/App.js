import React, { useState } from "react";
import "./App.css";

function App() {
  const [students, setStudents] = useState([]);
  const [name, setName] = useState("");
  const [course, setCourse] = useState("");

  const addStudent = (e) => {
    e.preventDefault();

    if (name === "" || course === "") {
      alert("Please enter all details");
      return;
    }

    const newStudent = {
      id: Date.now(),
      name: name,
      course: course
    };

    setStudents([...students, newStudent]);

    setName("");
    setCourse("");
  };

  const deleteStudent = (id) => {
    setStudents(students.filter((student) => student.id !== id));
  };

  return (
    <div className="container">
      <h1>Student Management System</h1>

      <form onSubmit={addStudent}>
        <input
          type="text"
          placeholder="Enter Student Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />

        <input
          type="text"
          placeholder="Enter Course"
          value={course}
          onChange={(e) => setCourse(e.target.value)}
        />

        <button type="submit">Add Student</button>
      </form>

      <h2>Student List</h2>

      {students.map((student) => (
        <div className="student" key={student.id}>
          <span>
            <b>{student.name}</b> - {student.course}
          </span>

          <button onClick={() => deleteStudent(student.id)}>
            Delete
          </button>
        </div>
      ))}
    </div>
  );
}

export default App;
